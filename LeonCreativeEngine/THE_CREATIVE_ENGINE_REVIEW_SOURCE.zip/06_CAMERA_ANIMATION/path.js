import * as THREE from '../node_modules/three/build/three.module.js';

// One 45-second path. Prototype and full film sample the same positions.
export const stations = Object.freeze([
  [0,   0,   0,    8],
  [1.5, .14, .07, -2],
  [3,   .5,  .1,  -13],
  [5,   .4,  .15, -25],
  [6,   1.8, .2,  -31],
  [10,  .1,  0,   -53],
  [14, -1.2, 0,   -76],
  [18,  .4,  .1,  -99],
  [22,  1.6, 0,  -121],
  [26,  .4,  0,  -145],
  [30, -.8,  .1, -168],
  [35,  .8,  .2, -197],
  [40,  0,   .1, -222],
  [45,  .1,  0,  -241],
]);
const v=i=>new THREE.Vector3(stations[i][1],stations[i][2],stations[i][3]);
const velocity=i=>{
  const a=Math.max(0,i-1),b=Math.min(stations.length-1,i+1);
  return v(b).sub(v(a)).divideScalar(stations[b][0]-stations[a][0]);
};
export function cameraPoint(seconds){
  const t=THREE.MathUtils.clamp(seconds,0,45);
  let i=0;while(i<stations.length-2&&t>stations[i+1][0])i++;
  const dt=stations[i+1][0]-stations[i][0],u=(t-stations[i][0])/dt;
  const u2=u*u,u3=u2*u;
  return v(i).multiplyScalar(2*u3-3*u2+1)
    .add(velocity(i).multiplyScalar(dt*(u3-2*u2+u)))
    .add(v(i+1).multiplyScalar(-2*u3+3*u2))
    .add(velocity(i+1).multiplyScalar(dt*(u3-u2)));
}
export function cameraPose(seconds){
  const position=cameraPoint(seconds);
  const ahead=cameraPoint(Math.min(45,seconds+.19));
  const behind=cameraPoint(Math.max(0,seconds-.19));
  const direction=ahead.sub(behind).normalize();
  const target=position.clone().addScaledVector(direction,8);
  const roll=.014*Math.sin(seconds*.38);
  const fov=50+1.2*Math.sin(seconds*.24);
  return {position,target,direction,roll,fov};
}
