import {cameraPose,stations} from './path.js';

const FPS=30;
const rows=[];
for(const [t] of stations.slice(1,-1)){
  const before=cameraPose(t-1/FPS),at=cameraPose(t),after=cameraPose(t+1/FPS);
  const stepBefore=before.position.distanceTo(at.position),stepAfter=at.position.distanceTo(after.position);
  const turnDeg=before.direction.angleTo(after.direction)*180/Math.PI;
  rows.push({boundarySeconds:t,stepBefore:+stepBefore.toFixed(4),stepAfter:+stepAfter.toFixed(4),turnDeg:+turnDeg.toFixed(3)});
  if(Math.abs(stepBefore-stepAfter)>.11||turnDeg>2.5)throw new Error(`Discontinuous camera at ${t}s`);
}
console.table(rows);
