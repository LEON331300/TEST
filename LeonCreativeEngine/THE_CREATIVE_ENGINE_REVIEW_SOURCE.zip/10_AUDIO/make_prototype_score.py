"""Generate an original, deterministic five-second stereo continuity-study cue."""
from math import cos, exp, pi, sin, tanh
from pathlib import Path
import struct
import wave

RATE = 48_000
DURATION = 5
DEST = Path(__file__).with_name("prototype-score.wav")

def env(t, at, decay):
    return 0.0 if t < at else exp(-(t - at) / decay)

with wave.open(str(DEST), "wb") as out:
    out.setnchannels(2)
    out.setsampwidth(2)
    out.setframerate(RATE)
    frames = bytearray()
    for n in range(RATE * DURATION):
        t = n / RATE
        build = 0.45 + 0.55 * min(1, t / 3)
        drone = (sin(2 * pi * 55 * t) * .12 + sin(2 * pi * 82.4 * t) * .047) * build
        shimmer = (sin(2 * pi * (660 * t + 9 * t * t)) * .012 + sin(2 * pi * 1320 * t) * .006)
        spark = env(t, .18, .13) * sin(2 * pi * (1320 * t + 180 * t * t)) * .065
        aperture = env(t, 2.88, .24) * (sin(2 * pi * 57 * t) * .15 + sin(2 * pi * 114 * t) * .042)
        reveal = env(t, 3.42, .32) * sin(2 * pi * 220 * t) * .04
        sweep = sin(2 * pi * (27 * t + 7.5 * t * t)) * .016 * min(1, t / 2)
        fade = min(1, t / .08, (DURATION - t) / .12)
        base = tanh((drone + shimmer + spark + aperture + reveal + sweep) * fade)
        left = max(-1, min(1, base + .013 * sin(2 * pi * 0.38 * t)))
        right = max(-1, min(1, base - .013 * sin(2 * pi * 0.38 * t)))
        frames.extend(struct.pack("<hh", round(left * 32767), round(right * 32767)))
    out.writeframes(frames)
print(DEST)
