# Visual production prompts / constraints

These are art-direction prompts for approved media generation or stock searches after the prototype review. They are not claims that footage has been made.

1. **AI filmmaking screen:** Cinematic production reel on a realistic in-world display: coherent photography, premium product macro imagery, practical lighting, natural human anatomy where people appear, no watermarks or fictional client marks. Palette must integrate with warm orange screen spill and graphite chamber.
2. **Software lab screen:** Functional browser/desktop/mobile interface with real hierarchy: navigation, content area, controls, state, and responsive relationship. Use approved Leon project screenshots when available. Any authored substitute must display `CONCEPT STUDY`.
3. **QA command screen:** Plausible testing viewport and test-status panel with actual checkpoint names rather than invented success statistics. Do not label it GamePilot QA unless verified source imagery is supplied.
4. **Design/content screens:** Use official LEON logo pixels only for brand marks; build original, clearly labeled concept mockups for layouts and media cards. Avoid unrelated brands or implied client relationships.

Every screen should be texture-mapped to a solid card or display whose frame, face, shadow and highlight share a transform. The dark architectural world, camera and orange guidance rail continue behind all screens.
