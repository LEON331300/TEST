# Motion-graphics system

The prototype uses physical canvas-textured phrase planes within the continuous 3D corridor. Their illumination/opacity is computed from absolute film time. For the full film, extend this system with authored software-screen textures and selected typographic structures while keeping all important copy deterministic and readable in portrait format.
