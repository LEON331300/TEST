# Reference motion analysis

## Source

`assets/ssstik.io_@saasservices17_1791988572151.mp4` is 29.605 seconds at 30 fps, 1020 × 576, with H.264 picture and AAC audio. `references/reference-contact-sheet.jpg` samples six frames at roughly five-second intervals.

## Observed visual language

- The reel alternates bright white editorial fields with dark interface scenes, maintaining a strong tonal rhythm.
- Large centered typography is revealed in short phrases. Select words receive a vivid accent color and copy assembles progressively rather than appearing as static slides.
- Rounded UI cards, input bars, cursor interactions, and floating media tiles create depth through scale, blur, and overlap.
- Soft defocus and blooming color fields bridge scenes. Masked reveals and brisk camera pushes keep the composition moving.
- Layouts remain sparse: one headline or one interface action dominates each beat while secondary objects supply motion.

## Adaptation for LEON TECHNOLOGIES

Use the reference for pace, spatial card behavior, progressive type, and tonal alternation. Replace its green accent and product interface identity with the verified orange, graphite, chrome, portrait, emblem, and original portfolio demonstrations. Do not copy its wording, product UI, or exact scene designs.

Scene 3 can inherit the fast card choreography and depth. Scene 4 can use the reference's modular gallery logic. Scene 5 can use soft blur as a connective device while preserving the brief's sketch-to-storyboard-to-3D transformation. The final reveal should slow down and hold long enough for the wordmark, tagline, call to action, and email to remain readable.
