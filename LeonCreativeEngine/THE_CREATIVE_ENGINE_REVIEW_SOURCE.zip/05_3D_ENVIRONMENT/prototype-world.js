import * as THREE from '../node_modules/three/build/three.module.js';
import {cameraPose} from '../06_CAMERA_ANIMATION/path.js';

const W=1080,H=1920;
const renderer=new THREE.WebGLRenderer({canvas:document.getElementById('world'),antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(1);renderer.setSize(W,H,false);
renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.45;
const scene=new THREE.Scene();scene.background=new THREE.Color(0x0b0d10);scene.fog=new THREE.Fog(0x0b0d10,22,65);
const camera=new THREE.PerspectiveCamera(50,W/H,.05,150);
scene.add(new THREE.HemisphereLight(0xffdbc1,0x080b13,1.45));
const key=new THREE.PointLight(0xff7b16,75,35);key.position.set(-3.6,4,-13);scene.add(key);
const white=new THREE.PointLight(0xdde6ff,45,27);white.position.set(4,3,-28);scene.add(white);
const graphite=new THREE.MeshPhysicalMaterial({color:0x171c22,metalness:.68,roughness:.34,clearcoat:.5});
const titanium=new THREE.MeshPhysicalMaterial({color:0x363d45,metalness:.86,roughness:.25,clearcoat:1,clearcoatRoughness:.18});
const orange=new THREE.MeshStandardMaterial({color:0xff6b00,emissive:0xff4a00,emissiveIntensity:1.4,metalness:.25,roughness:.2});
const glass=new THREE.MeshPhysicalMaterial({color:0x9eb3c4,metalness:.12,roughness:.12,transparent:true,opacity:.19,depthWrite:false,side:THREE.DoubleSide});
const soft=new THREE.MeshBasicMaterial({color:0xffa04b,transparent:true,opacity:.28,depthWrite:false});
function box(parent,x,y,z,w,h,d,mat){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);parent.add(m);return m}
function torus(parent,x,y,z,r,t,mat){const m=new THREE.Mesh(new THREE.TorusGeometry(r,t,12,80),mat);m.position.set(x,y,z);parent.add(m);return m}

// A single architectural corridor, open to the portrait chamber. The camera
// travels inside it; geometry stays in one coordinate system for all 5 seconds.
const floor=box(scene,0,-3.7,-18,17,.22,92,graphite);
box(scene,0,-3.48,-18,6,.08,92,titanium);
for(let side of [-1,1]){
  box(scene,side*3.2,-3.34,-18,.055,.08,92,orange);
  box(scene,side*5.6,-.2,-18,.3,7.2,92,graphite);
  box(scene,side*5.15,3.5,-18,.8,.12,92,titanium);
}
for(let z=5;z>=-49;z-=6){
  for(let side of [-1,1]){
    box(scene,side*4.75,0,z,.32,7.3,.34,titanium);
    box(scene,side*4.5,-3.13,z,.75,.055,.44,orange);
  }
  box(scene,0,3.55,z,9.8,.36,.34,titanium);
  box(scene,0,3.35,z,7.8,.035,.09,soft);
}
for(let z=1;z>=-43;z-=9){
  const slab=box(scene,0,-3.35,z,3.2,.045,1.1,titanium);
  slab.material=titanium;
}
// Near-black titanium fin at the opening gives the first frame a macro surface.
box(scene,-3.0,.2,5.1,.28,4.8,1.35,titanium);
const sparkMat=orange.clone();sparkMat.transparent=true;
const spark=new THREE.Mesh(new THREE.SphereGeometry(.105,16,16),sparkMat);spark.position.set(0,.05,2.3);scene.add(spark);
const halo=torus(scene,0,.05,2.25,.37,.014,soft);halo.rotation.y=.3;
const lead=box(scene,0,-3.3,-5,.07,.06,18,orange);

function typeTexture(lines,color='#ffffff'){
  const c=document.createElement('canvas');c.width=1024;c.height=300;const ctx=c.getContext('2d');
  ctx.clearRect(0,0,1024,300);ctx.textAlign='center';ctx.textBaseline='middle';ctx.shadowColor='#000';ctx.shadowBlur=20;
  ctx.fillStyle=color;ctx.font='900 123px Inter, Arial, sans-serif';ctx.fillText(lines,512,145,970);
  ctx.fillStyle='#ff8128';ctx.fillRect(380,265,264,7);
  const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;return tex;
}
function phrase(text,z,width,color){
  const mat=new THREE.MeshBasicMaterial({map:typeTexture(text,color),transparent:true,opacity:0,side:THREE.DoubleSide,depthWrite:false,toneMapped:false});
  const plane=new THREE.Mesh(new THREE.PlaneGeometry(width,width*300/1024),mat);plane.position.set(0,.4,z);scene.add(plane);return plane;
}
const phrases=[phrase('WHAT IF',-4,4.1,'#ffffff'),phrase('YOUR IDEAS',-8.6,4.25,'#ff9a3d'),phrase('COULD MOVE?',-12.4,1.25,'#ffffff')];
phrases[2].position.x=.45;
const aperture=new THREE.Group();aperture.position.set(.5,.1,-13);scene.add(aperture);
for(let i=0;i<4;i++){const ring=torus(aperture,0,0,-i*.22,2.4+i*.08,.08,i%2?graphite:orange);ring.rotation.y=i*.06}
for(let i=0;i<8;i++){
  const a=i*Math.PI/4;
  const strut=box(aperture,Math.cos(a)*3.55,Math.sin(a)*3.55,-.4,.1,.9,.12,i%2?graphite:titanium);strut.rotation.z=a;
}

// Actual portrait texture is mounted on a screen, with all frame parts grouped.
const portrait=new THREE.Group();portrait.position.set(-1.2,-.05,-39);scene.add(portrait);
box(portrait,0,0,-.12,3.6,4.8,.25,titanium);
box(portrait,0,0,-.015,3.38,4.58,.025,graphite);
const portraitMat=new THREE.MeshBasicMaterial({color:0xffffff,side:THREE.DoubleSide,toneMapped:false});
const portraitPlane=new THREE.Mesh(new THREE.PlaneGeometry(3.2,3.2),portraitMat);portraitPlane.position.set(0,.54,.04);portrait.add(portraitPlane);
for(let side of [-1,1])box(portrait,side*1.76,0,.09,.045,4.78,.06,orange);
box(portrait,0,-2.38,.09,3.58,.05,.06,orange);
const portraitGlow=new THREE.PointLight(0xff8530,45,10);portraitGlow.position.set(-3,1,-36);scene.add(portraitGlow);

const title=phrase('MEET LEON',-37.7,3.15,'#ffffff');title.position.set(2.15,1.48,-37.7);
const role=phrase('CREATIVE TECHNOLOGIST',-37.6,3.0,'#ff9a3d');role.position.set(2.13,.73,-37.6);
const frame=box(scene,2.15,-.02,-37.8,3.8,2.7,.11,graphite);
const panelMat=graphite.clone();panelMat.transparent=true;panelMat.opacity=0;panelMat.depthWrite=false;frame.material=panelMat;
const annotation=box(scene,2.12,-1.55,-37.7,2.7,.035,.06,orange);
const annotationMat=orange.clone();annotationMat.transparent=true;annotationMat.opacity=0;annotationMat.depthWrite=false;annotation.material=annotationMat;

const dustGeo=new THREE.BufferGeometry();const dustData=new Float32Array(220*3);
const rand=i=>{const x=Math.sin(i*17.11+8.17)*31771.779;return x-Math.floor(x)};
for(let i=0;i<220;i++){dustData[i*3]=(rand(i*3)-.5)*10;dustData[i*3+1]=(rand(i*3+1)-.5)*6;dustData[i*3+2]=6-rand(i*3+2)*53}
dustGeo.setAttribute('position',new THREE.BufferAttribute(dustData,3));
const dust=new THREE.Points(dustGeo,new THREE.PointsMaterial({color:0xf4a066,size:.035,transparent:true,opacity:.6}));scene.add(dust);

const smooth=x=>{x=THREE.MathUtils.clamp(x,0,1);return x*x*(3-2*x)};
function pulse(t,on,off){return smooth((t-on)/.27)*(1-smooth((t-off)/.3))}
function renderAt(t){
  const pose=cameraPose(t);camera.position.copy(pose.position);camera.fov=pose.fov;camera.updateProjectionMatrix();
  camera.up.set(Math.sin(pose.roll),Math.cos(pose.roll),0);camera.lookAt(pose.target);
  phrases.forEach((p,i)=>{p.material.opacity=pulse(t,[.18,1.10,2.03][i],[1.1,2.00,2.87][i]);p.position.y=.4+Math.sin((t-i*.15)*1.4)*.035});
  title.material.opacity=pulse(t,3.43,6.1);role.material.opacity=pulse(t,5,6.2);
  panelMat.opacity=smooth((t-5)/.45);annotationMat.opacity=smooth((t-5)/.45);
  spark.scale.setScalar(.65+1.8*smooth(t/.65));spark.material.emissiveIntensity=1.1+1.4*Math.sin(t*8)**2;spark.material.opacity=1-smooth((t-.18)/.7);
  halo.scale.setScalar(1+.65*smooth(t/.8));
  lead.scale.x=.7+.3*smooth(t/2.6);
  key.intensity=75+13*Math.sin(t*1.1);portraitGlow.intensity=30+16*smooth((t-3)/1.4);
  renderer.render(scene,camera);
}
// HyperFrames waits for the actual portrait image before seeking capture frames.
window.__hf=window.__hf||{};window.__hf.buildReady=window.__hf.buildReady||{};
let release;window.__hf.buildReady.portrait=new Promise(resolve=>{release=resolve});
new THREE.TextureLoader().load('./02_BRAND_ASSETS/leon-portrait-original.png',tex=>{
  tex.colorSpace=THREE.SRGBColorSpace;tex.anisotropy=4;portraitMat.map=tex;portraitMat.needsUpdate=true;
  release();renderAt(window.__hfThreeTime||0);
},undefined,err=>{console.error('Portrait texture failed to load',err);release()});
window.addEventListener('hf-seek',event=>renderAt(event.detail.time));
renderAt(window.__hfThreeTime||0);
