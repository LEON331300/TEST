# LEON TECHNOLOGIES — THE CREATIVE ENGINE

This new project is the review package for a planned **45-second, 9:16, one-camera** motion portfolio. It is separate from the completed 30-second Leon film in `/workspace/LeonPortfolio`.

The current media deliverable is a **five-second opening/portrait continuity prototype**, with no voice-over. Its Three.js `PerspectiveCamera` follows the first five seconds of a single authored 45-second cubic path. The original supplied portrait is mapped without changing facial features or aspect ratio. The official logo source has been preserved for the later brand sequence; it is not displayed in this opening prototype.

Review the [storyboard](13_DOCUMENTATION/STORYBOARD.md), [camera path](06_CAMERA_ANIMATION/CAMERA_PATH.md), [production plan](13_DOCUMENTATION/PRODUCTION_PLAN.md), and [asset/source ledger](04_SOURCED_MEDIA/SOURCES.md). The production brief asks for approval of the plan before rendering the full film.

To reproduce locally, run `npm ci`, `python3 10_AUDIO/make_prototype_score.py`, `npm run check`, then `npm run render:prototype`. HyperFrames v0.8.145, Three.js 0.180.0, GSAP 3.14.2, and Inter 5.2.8 are pinned. `node 06_CAMERA_ANIMATION/verify_path.mjs` checks position and direction at all path stations.
