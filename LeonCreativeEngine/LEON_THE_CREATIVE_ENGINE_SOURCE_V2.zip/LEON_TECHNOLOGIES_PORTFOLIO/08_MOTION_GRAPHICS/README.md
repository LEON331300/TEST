# Motion graphics

Opening word planes, gallery labels, service screens, and closing copy are canvas textures mounted on physical 3D planes. Their positions share the one-camera world. The first three word planes use deterministic absolute-time opacity; subsequent cards gain motion and parallax from the uninterrupted camera move. Source imagery is labeled `VISUAL STUDY` and original interface artwork is labeled `CONCEPT STUDY`.
