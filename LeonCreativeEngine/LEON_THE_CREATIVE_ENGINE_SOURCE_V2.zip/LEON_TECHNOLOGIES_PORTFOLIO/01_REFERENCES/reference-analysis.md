# Visual reference analysis

The supplied motion reference informed the desired pace, spatial cards, progressive type, and tonal alternation. This film uses its own connected corridor, LEON orange/graphite palette, original concept screens, NASA-sourced visual-study cards, and the supplied official logo. It does not reproduce the reference's copy, UI, or exact layouts.
