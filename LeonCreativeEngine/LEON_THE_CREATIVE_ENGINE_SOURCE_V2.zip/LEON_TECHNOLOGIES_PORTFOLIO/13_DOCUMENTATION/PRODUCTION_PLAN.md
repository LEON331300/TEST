# Production specification

This approved production follows the user's direction to remove Leon's image and blend in online cards. The supplied portrait was removed from this project's assets and from the film. The official LEON logo remains unaltered.

The project uses one Three.js scene and one continuous camera path (`06_CAMERA_ANIMATION/path.js`) for all 45 seconds. HyperFrames samples the scene at 30 fps. NASA gallery cards are framed as illustrative visual studies. Original procedural card graphics represent service areas. The score is original stereo audio at 48 kHz. Output is H.264/AAC, portrait 1080 × 1920. Source attribution is in `04_SOURCED_MEDIA/SOURCES.md`.

Validation consists of camera-path continuity, HyperFrames check, representative snapshots, and a decoded frame/audio audit of the final export.
