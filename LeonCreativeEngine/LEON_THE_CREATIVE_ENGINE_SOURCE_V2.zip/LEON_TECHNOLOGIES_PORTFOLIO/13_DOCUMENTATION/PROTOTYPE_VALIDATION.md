# Superseded prototype

The earlier five-second portrait prototype was removed from this project's deliverables after the user requested that Leon's image be removed. The final 45-second film uses three NASA-sourced gallery cards instead. See `FINAL_VALIDATION.md` for current checks.
