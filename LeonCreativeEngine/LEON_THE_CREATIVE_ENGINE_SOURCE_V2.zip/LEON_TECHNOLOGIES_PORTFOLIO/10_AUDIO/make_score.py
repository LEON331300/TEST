"""Generate the original 45-second stereo instrumental score for the film."""
from math import exp, pi, sin, tanh
from pathlib import Path
import struct
import wave

RATE=48_000
DURATION=45
DEST=Path(__file__).with_name('creative-engine-score.wav')
beats=(0.18,2.9,5.8,9.8,13.8,17.8,21.8,25.8,29.8,34.8,39.8)
with wave.open(str(DEST),'wb') as out:
    out.setnchannels(2);out.setsampwidth(2);out.setframerate(RATE)
    chunk=bytearray()
    for n in range(RATE*DURATION):
        t=n/RATE
        section=min(1,t/34)
        drone=(sin(2*pi*55*t)*.10+sin(2*pi*82.41*t)*.043+sin(2*pi*110*t)*.025)*(.42+.58*section)
        rhythm=(sin(2*pi*2.0*t)*.5+.5)**8 * sin(2*pi*165*t)*(.006+.012*section)
        shimmer=(sin(2*pi*(620*t+2.5*t*t))*.009+sin(2*pi*1240*t)*.004)
        trans=0.0
        for b in beats:
            if b<=t<b+.7:
                dt=t-b;trans+=exp(-dt*8)*(sin(2*pi*(65*dt+35*dt*dt))*.09+sin(2*pi*980*dt)*.018)
        finale=(sin(2*pi*220*t)*.014+sin(2*pi*329.63*t)*.009)*max(0,min(1,(t-34)/5))
        fade=max(0,min(1,t/.08,(DURATION-t)/.8))
        v=tanh((drone+rhythm+shimmer+trans+finale)*fade)
        l=max(-1,min(1,v+.006*sin(2*pi*.31*t)))
        r=max(-1,min(1,v-.006*sin(2*pi*.31*t)))
        chunk.extend(struct.pack('<hh',round(l*32767),round(r*32767)))
        if len(chunk)>=192_000:
            out.writeframes(chunk);chunk.clear()
    if chunk:out.writeframes(chunk)
print(DEST)
