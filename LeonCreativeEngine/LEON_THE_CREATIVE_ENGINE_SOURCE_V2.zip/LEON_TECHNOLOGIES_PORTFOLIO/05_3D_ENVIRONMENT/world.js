import * as THREE from '../node_modules/three/build/three.module.js';
import {cameraPose} from '../06_CAMERA_ANIMATION/path.js';

const W=1080,H=1920,DURATION=45;
const renderer=new THREE.WebGLRenderer({canvas:document.getElementById('world'),antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(1);renderer.setSize(W,H,false);
renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.4;
const scene=new THREE.Scene();scene.background=new THREE.Color(0x090b0e);scene.fog=new THREE.Fog(0x090b0e,32,80);
const camera=new THREE.PerspectiveCamera(50,W/H,.05,180);
scene.add(new THREE.HemisphereLight(0xffb77e,0x071018,1.35));
const key=new THREE.PointLight(0xff7820,95,46);scene.add(key);
const fill=new THREE.PointLight(0x9db7dc,52,40);scene.add(fill);
const graphite=new THREE.MeshPhysicalMaterial({color:0x171c22,metalness:.67,roughness:.34,clearcoat:.45});
const titanium=new THREE.MeshPhysicalMaterial({color:0x383f47,metalness:.83,roughness:.25,clearcoat:1});
const orange=new THREE.MeshStandardMaterial({color:0xff7218,emissive:0xff4d08,emissiveIntensity:1.3,metalness:.25,roughness:.24});
const ember=new THREE.MeshBasicMaterial({color:0xff9a45,transparent:true,opacity:.22,depthWrite:false});
const ivory=new THREE.MeshBasicMaterial({color:0xecebe8,toneMapped:false});
function box(parent,x,y,z,w,h,d,mat){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);parent.add(m);return m}
function ring(parent,x,y,z,r,t,mat){const m=new THREE.Mesh(new THREE.TorusGeometry(r,t,8,64),mat);m.position.set(x,y,z);parent.add(m);return m}
function canvasTexture(draw,w=1024,h=1024){const c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=4;return t}
function textTexture(lines,{color='#f5f5f1',size=112,align='center',accent=true}={}){return canvasTexture((ctx,w,h)=>{ctx.clearRect(0,0,w,h);ctx.textAlign=align;ctx.textBaseline='middle';ctx.fillStyle=color;ctx.font=`800 ${size}px Inter, Arial, sans-serif`;const y=lines.length===1?145:120;lines.forEach((line,i)=>ctx.fillText(line,align==='center'?w/2:48,y+i*116,w-96));if(accent){ctx.fillStyle='#ff7b26';ctx.fillRect(w/2-120,270,240,7)}},1024,320)}
function textPlane(parent,lines,x,y,z,w,size=112,color='#f5f5f1'){const mat=new THREE.MeshBasicMaterial({map:textTexture(lines,{size,color}),transparent:true,side:THREE.DoubleSide,depthWrite:false,toneMapped:false});const m=new THREE.Mesh(new THREE.PlaneGeometry(w,w*320/1024),mat);m.position.set(x,y,z);parent.add(m);return m}
function screen(parent,x,y,z,w,h,tex,accent=true){const g=new THREE.Group();g.position.set(x,y,z);parent.add(g);box(g,0,0,-.09,w+.18,h+.18,.18,titanium);box(g,0,0,.012,w+.07,h+.07,.018,graphite);const mat=new THREE.MeshBasicMaterial({map:tex,toneMapped:false,side:THREE.DoubleSide});const p=new THREE.Mesh(new THREE.PlaneGeometry(w,h),mat);p.position.z=.035;g.add(p);if(accent){box(g,0,-h/2-.11,.08,w+.21,.045,.055,orange);for(const s of [-1,1])box(g,s*(w/2+.1),0,.07,.033,h+.19,.055,orange)}return {g,mat}}

// Continuous 250-unit gallery. There are no scene changes or camera resets.
box(scene,0,-3.7,-120,17,.22,270,graphite);
box(scene,0,-3.47,-120,6,.065,270,titanium);
for(const side of [-1,1]){box(scene,side*3.35,-3.34,-120,.055,.075,270,orange);box(scene,side*5.7,-.2,-120,.28,7.3,270,graphite);box(scene,side*5.18,3.5,-120,.85,.12,270,titanium)}
for(let z=5;z>=-252;z-=7){for(const side of [-1,1]){box(scene,side*4.82,0,z,.30,7.3,.32,titanium);box(scene,side*4.52,-3.12,z,.78,.055,.46,orange)}box(scene,0,3.55,z,9.9,.34,.32,titanium);box(scene,0,3.34,z,7.8,.035,.09,ember)}
for(let z=1;z>=-249;z-=10)box(scene,0,-3.34,z,3.25,.04,1.05,titanium);
box(scene,-3.0,.2,5.1,.28,4.8,1.35,titanium);
const sparkMat=orange.clone();sparkMat.transparent=true;const spark=new THREE.Mesh(new THREE.SphereGeometry(.105,16,16),sparkMat);spark.position.set(0,.05,2.3);scene.add(spark);
const halo=ring(scene,0,.05,2.25,.37,.014,ember);halo.rotation.y=.3;
const opening=[textPlane(scene,['WHAT IF'],0,.4,-4,4.1),textPlane(scene,['YOUR IDEAS'],0,.4,-8.6,4.25,112,'#ffa450'),textPlane(scene,['COULD MOVE?'],.45,.4,-12.4,2.2,110)];
for(let i=0;i<4;i++){const r=ring(scene,.5,.1,-13-i*.22,2.4+i*.08,.08,i%2?titanium:orange);r.rotation.y=i*.06}

// All media screens are diegetic objects. NASA imagery is labeled as a visual study.
const media={};const loadList=[
 ['boot','./04_SOURCED_MEDIA/nasa/moon-bootprint.webp'],
 ['mars','./04_SOURCED_MEDIA/nasa/mars.webp'],
 ['earth','./04_SOURCED_MEDIA/nasa/earth.webp'],
 ['logo','./02_BRAND_ASSETS/leon-primary-lockup-reference.png']
];
const pending=[];const loader=new THREE.TextureLoader();
for(const [name,url] of loadList)pending.push(new Promise((resolve,reject)=>loader.load(url,t=>{t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=4;media[name]=t;resolve()},undefined,reject)));
window.__hf=window.__hf||{};window.__hf.buildReady=window.__hf.buildReady||{};
window.__hf.buildReady.media=Promise.all(pending).then(()=>{buildScreens();renderAt(window.__hfThreeTime||0)});

function designTexture(kind){return canvasTexture((c,w,h)=>{
 const grad=c.createLinearGradient(0,0,w,h);grad.addColorStop(0,'#202b36');grad.addColorStop(.55,'#0d111a');grad.addColorStop(1,'#10161e');c.fillStyle=grad;c.fillRect(0,0,w,h);
 c.strokeStyle='rgba(255,127,44,.18)';for(let i=0;i<11;i++){c.beginPath();c.moveTo(i*w/10,0);c.lineTo(i*w/10,h);c.stroke()}
 c.fillStyle='#ff7824';c.fillRect(74,70,112,8);c.fillStyle='#b2c4d6';c.font='700 29px Inter,Arial';c.fillText('LEON / CONCEPT STUDY',74,120);
 if(kind==='ai'){for(let i=0;i<6;i++){c.strokeStyle=`rgba(255,125,35,${.12+i*.08})`;c.lineWidth=9;c.beginPath();c.arc(512,550,90+i*64,0,Math.PI*2);c.stroke()}c.fillStyle='#f6f2eb';c.font='900 110px Inter,Arial';c.fillText('IMAGINE',235,570)}
 if(kind==='motion'){c.fillStyle='#f0ece6';for(let i=0;i<5;i++){c.save();c.translate(290+i*100,520+i*25);c.rotate(.18*i);c.fillRect(-33,-150,66,300);c.restore()}c.fillStyle='#ff7b29';c.beginPath();c.arc(565,500,140,0,Math.PI*2);c.fill()}
 if(kind==='web'){c.fillStyle='#141e2a';c.fillRect(125,205,775,625);c.strokeStyle='#ff792d';c.lineWidth=5;c.strokeRect(125,205,775,625);c.fillStyle='#2d3d50';c.fillRect(170,260,280,480);c.fillStyle='#f1efea';c.font='800 72px Inter,Arial';c.fillText('build',490,380);c.fillStyle='#ff792d';c.fillRect(493,430,280,28);c.fillRect(493,480,200,18);c.fillStyle='#667d91';c.fillRect(493,535,290,18)}
 if(kind==='qa'){for(let i=0;i<4;i++){c.fillStyle=i===3?'#ff7828':'#203044';c.fillRect(135,210+i*145,755,105);c.strokeStyle='#617c91';c.strokeRect(135,210+i*145,755,105);c.fillStyle='#e7e9ea';c.font='700 42px Inter,Arial';c.fillText(['01  DISCOVER','02  TEST','03  REFINE','04  RELEASE'][i],195,275+i*145)}}
 if(kind==='brand'){c.fillStyle='#ff7828';c.beginPath();c.moveTo(320,300);c.lineTo(710,510);c.lineTo(320,740);c.closePath();c.fill();c.fillStyle='#f4f1ed';c.font='900 86px Inter,Arial';c.fillText('IDENTITY',175,880)}
 if(kind==='strategy'){for(let i=0;i<6;i++){c.fillStyle=i%2?'#42536a':'#ff7828';c.fillRect(155+i*118,730-i*72,74,80+i*72)}c.strokeStyle='#f1f0eb';c.lineWidth=11;c.beginPath();c.moveTo(140,650);c.bezierCurveTo(380,600,500,460,830,215);c.stroke()}
 if(kind==='converge'){for(let i=0;i<16;i++){const a=i*Math.PI/8;c.fillStyle=i%4?'#a6afba':'#ff7c29';c.beginPath();c.arc(512+Math.cos(a)*270,510+Math.sin(a)*270,11+i%3*7,0,Math.PI*2);c.fill();c.strokeStyle='rgba(255,127,41,.4)';c.beginPath();c.moveTo(512,510);c.lineTo(512+Math.cos(a)*270,510+Math.sin(a)*270);c.stroke()}c.fillStyle='#fff';c.font='900 82px Inter,Arial';c.fillText('CREATE',337,530)}
 c.fillStyle='#68798a';c.font='500 28px Inter,Arial';c.fillText('IDEAS  /  VISUALS  /  SOLUTIONS  /  BEYOND',74,970);
 })}
function label(parent,words,z,w=4.5,x=0,y=2.65){return textPlane(parent,[words],x,y,z,w,92)}
function buildScreens(){
 // Three staggered NASA media cards replace the former portrait reveal.
 const gallery=[
  {name:'APOLLO / VISUAL STUDY',tex:media.boot,x:-.95,z:-36.5,w:2.55,h:1.75},
  {name:'MARS / VISUAL STUDY',tex:media.mars,x:1.7,z:-39.5,w:2.05,h:1.45},
  {name:'EARTH / VISUAL STUDY',tex:media.earth,x:-1.55,z:-43,w:2.1,h:1.5}
 ];
 for(const item of gallery){screen(scene,item.x,.05,item.z,item.w,item.h,item.tex);label(scene,item.name,item.z+.08,item.w,item.x,item.h/2+.5)}
 label(scene,'THE CREATIVE ENGINE',-34,3.4,0,2.55);
 const phases=[
  {title:'AI FILMMAKING',z:-60,kind:'ai',x:-.6,detail:'FROM PROMPT TO POSSIBILITY'},
  {title:'MOTION & EDITING',z:-83,kind:'motion',x:.7,detail:'EVERY FRAME HAS PURPOSE'},
  {title:'SOFTWARE & WEB',z:-106,kind:'web',x:-.6,detail:'IDEAS MADE USEFUL'},
  {title:'QUALITY ASSURANCE',z:-129,kind:'qa',x:.6,detail:'BUILT TO WORK BEAUTIFULLY'},
  {title:'BRAND & DESIGN',z:-153,kind:'brand',x:-.5,detail:'A DISTINCT POINT OF VIEW'},
  {title:'CONTENT & STRATEGY',z:-177,kind:'strategy',x:.6,detail:'STORIES WITH DIRECTION'},
  {title:'ONE CREATIVE ENGINE',z:-204,kind:'converge',x:0,detail:'EVERY DISCIPLINE CONNECTED'}
 ];
 for(const p of phases){screen(scene,p.x,.1,p.z,3.5,3.5,designTexture(p.kind));label(scene,p.title,p.z+.1,4.7,p.x,2.6);textPlane(scene,[p.detail],p.x,-2.2,p.z+.1,3.5,52,'#ffa85c');const beam=new THREE.PointLight(0xff6320,28,12);beam.position.set(p.x-2,1,p.z+3);scene.add(beam)}
 // Brand culmination and contact are placed along the same uninterrupted path.
 screen(scene,0,.65,-230,5.0,1.88,media.logo,false);
 label(scene,'IDEAS IN MOTION',-229.9,4.4,0,-1.05);
 const end=new THREE.Group();end.position.set(0,0,-253);scene.add(end);
 box(end,0,0,-.17,6.8,7.5,.24,graphite);
 screen(end,0,1.5,.02,5.1,1.92,media.logo,false);
 textPlane(end,['LEON TECHNOLOGIES'],0,.1,.14,4.6,76);
 textPlane(end,["LET'S BUILD SOMETHING",'EXTRAORDINARY.'],0,-1.3,.14,5.4,69,'#ffa450');
 textPlane(end,['eakinnifesi@gmail.com'],0,-2.7,.14,4.8,69,'#f5f5f1');
 box(end,0,-3.27,.16,4.9,.04,.06,orange);
}

const dustData=new Float32Array(440*3);const rand=i=>{const x=Math.sin(i*17.11+8.17)*31771.779;return x-Math.floor(x)};
for(let i=0;i<440;i++){dustData[i*3]=(rand(i*3)-.5)*10;dustData[i*3+1]=(rand(i*3+1)-.5)*6;dustData[i*3+2]=6-rand(i*3+2)*260}
const dustGeo=new THREE.BufferGeometry();dustGeo.setAttribute('position',new THREE.BufferAttribute(dustData,3));scene.add(new THREE.Points(dustGeo,new THREE.PointsMaterial({color:0xf4a066,size:.035,transparent:true,opacity:.55})));
const smooth=x=>{x=THREE.MathUtils.clamp(x,0,1);return x*x*(3-2*x)};
function pulse(t,on,off){return smooth((t-on)/.27)*(1-smooth((t-off)/.3))}
function renderAt(raw){const t=THREE.MathUtils.clamp(raw,0,DURATION);const pose=cameraPose(t);camera.position.copy(pose.position);camera.fov=pose.fov;camera.updateProjectionMatrix();camera.up.set(Math.sin(pose.roll),Math.cos(pose.roll),0);camera.lookAt(pose.target);opening.forEach((p,i)=>{p.material.opacity=pulse(t,[.18,1.1,2.03][i],[1.1,2,2.87][i]);p.position.y=.4+Math.sin((t-i*.15)*1.4)*.035});spark.scale.setScalar(.65+1.8*smooth(t/.65));spark.material.emissiveIntensity=1.1+1.4*Math.sin(t*8)**2;spark.material.opacity=1-smooth((t-.18)/.7);halo.scale.setScalar(1+.65*smooth(t/.8));key.position.copy(pose.position).add(new THREE.Vector3(-3.6,3,-8));fill.position.copy(pose.position).add(new THREE.Vector3(3.6,2,-22));key.intensity=78+12*Math.sin(t*1.2);renderer.render(scene,camera)}
window.addEventListener('hf-seek',event=>renderAt(event.detail.time));renderAt(window.__hfThreeTime||0);
