# One continuous 45-second camera path

`path.js` defines Hermite-spline position stations from z=8 to z=−241. `cameraPose(t)` derives the view direction from neighboring path positions, so the camera passes all visual-study and service-card chambers without cuts or teleports. The final brand panel is at z=−253, ahead of the camera at its z=−241 endpoint.

The camera's x-position arcs gently between −1.2 and 1.8 world units, while y stays near 0 and the world geometry remains in one coordinate system. `verify_path.mjs` checks station continuity and angular change at boundaries. The architecture, gallery, interface cards, brand plaque, and final panel are all fixed 3D objects in the same world.
