# LEON TECHNOLOGIES — THE CREATIVE ENGINE

A 45-second, 1080 × 1920, 30 fps motion portfolio built as one continuous Three.js camera move. It has an original instrumental score and no voice-over. The supplied LEON logo remains intact. Leon's portrait is not used.

The opening enters a connected gallery of three NASA-sourced media cards, each labeled `VISUAL STUDY`. Seven original concept screens cover AI filmmaking, motion/editing, software/web, QA, branding, strategy, and convergence. The camera then approaches the official LEON logo and a final brand message. Concept graphics illustrate capabilities; they are not presented as verified client projects.

Run `npm ci`, `python3 10_AUDIO/make_score.py`, `npm run check`, `npm run snapshot`, then `npm run render:full`. HyperFrames v0.8.145, Three.js 0.180.0, GSAP 3.14.2, and Inter 5.2.8 are pinned. `node 06_CAMERA_ANIMATION/verify_path.mjs` checks camera continuity.

The final MP4 is in `12_FINAL_RENDER`. Source credits and usage are in `04_SOURCED_MEDIA/SOURCES.md`.
